package Example.Data;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class HotelDAO {
	
	private JdbcTemplate jdbctemp;

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}
	
	public int saveHotel(Hotel h)
	{
		String query="insert into hotel values('"+ h.getId()+"','" + h.getName()+ "','" + h.getCity() + "','" +h.getPhoneNumber() +"')";
		
	    return jdbctemp.update(query);
	}
	
	public int updateHotel(Hotel h)
	{
		String query="update hotel set name='" + h.getName() + "',city='" + h.getCity() + "',phoneNumber='" + h.getPhoneNumber() + "' where id='" + h.getId() + "'";
		
	    return jdbctemp.update(query);
	}
	
	public int deleteHotel(Hotel h)
	{
		String query="delete from hotel where id='" + h.getId() + "'"; 
		
	    return jdbctemp.update(query);
	}
	
	public List<Hotel> viewHotel(){
		String query1 = "select *from Hotel";
		List<Hotel> hotel =jdbctemp.query(query1,new HotelMapper());
		return hotel;
	}

}
