package Example.Data;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class HotelMapper implements RowMapper<Hotel> {
	public Hotel mapRow(ResultSet rs,int rowno) throws SQLException
	{
		Hotel hotel=new Hotel();
		hotel.setId(rs.getInt(1));
		hotel.setName(rs.getString(2));
		hotel.setCity(rs.getString(3));
		hotel.setPhoneNumber(rs.getLong(4));
		return hotel;
	}

}
