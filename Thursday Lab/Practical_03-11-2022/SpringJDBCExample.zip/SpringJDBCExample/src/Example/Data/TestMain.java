package Example.Data;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		ApplicationContext beanFactory = new ClassPathXmlApplicationContext("applicationContext.xml");
		HotelDAO myBean = (HotelDAO) beanFactory.getBean("hdao");
        
        /*//INSERT DATA
        System.out.println(myBean.saveHotel(new Hotel(101,"The Oberoi","Mumbai",902751847)));
        System.out.println(myBean.saveHotel(new Hotel(102,"Le Sutra","Mumbai",827381528)));
      
		//UPDATE DATA
        System.out.println(myBean.updateHotel(new Hotel(101,"The Oberoi","Mumbai",781463952)));
        
        //DELETE DATA
        Hotel h = new Hotel();
        h.setId(101);
        System.out.println(myBean.deleteHotel(h));*/
        
		List<Hotel> h1=myBean.viewHotel();
        System.out.println("ID \t\t\t\t"+"NAME \t\t\t\t\t\t"+"CITY \t\t\t\t"+"PHONENUMBER \t\t\t\t");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
        for(Hotel hotel:h1)
        {
        	System.out.println(hotel.getId()+" \t\t\t\t"+hotel.getName()+" \t\t\t\t\t"+hotel.getCity()+" \t\t\t\t"+hotel.getPhoneNumber());
        }

	}

}
